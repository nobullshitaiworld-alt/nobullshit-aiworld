const yearEl = document.getElementById("year");

if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}

const root = document.documentElement;

window.addEventListener("pointermove", (event) => {
  const { innerWidth, innerHeight } = window;
  const x = (event.clientX / innerWidth) * 100;
  const y = (event.clientY / innerHeight) * 100;

  root.style.setProperty("--pointer-x", `${x}%`);
  root.style.setProperty("--pointer-y", `${y}%`);

  const shell = document.querySelector(".panel-shell");

  if (shell) {
    const tiltX = (event.clientX / innerWidth - 0.5) * 18;
    const tiltY = (event.clientY / innerHeight - 0.5) * -18;
    shell.style.transform = `rotateX(${8 + tiltY}deg) rotateY(${tiltX - 9}deg) translateY(-4px)`;
  }
});

window.addEventListener("pointerleave", () => {
  const shell = document.querySelector(".panel-shell");
  if (shell) {
    shell.style.transform = "rotateX(8deg) rotateY(-9deg) translateY(0)";
  }
  root.style.setProperty("--pointer-x", "50%");
  root.style.setProperty("--pointer-y", "22%");
});

const form = document.getElementById("lead-form");

if (form) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const button = form.querySelector("button");
    const input = form.querySelector("input");

    if (button && input) {
      button.textContent = "Request received";
      input.value = "";
      input.placeholder = "You’re on the list";
      button.disabled = true;
    }
  });
}

const chatLauncher = document.getElementById("chat-launcher");
const chatPanel = document.getElementById("chat-panel");
const chatClose = document.getElementById("chat-close");
const chatMinimize = document.getElementById("chat-minimize");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const chatMessages = document.getElementById("chat-messages");
const quickTaskButtons = document.querySelectorAll("[data-task]");
const taskHistoryList = document.getElementById("task-history-list");
const taskResult = document.getElementById("task-result");
const welcomeAudio = document.getElementById("welcome-audio");
const botAgents = document.querySelectorAll(".bot-agent");
const activityEntries = document.querySelectorAll(".activity-entry span:last-child");

const welcomeText = "Welcome to NoBullshitAIWorld. I'm glad you're here. Let's build your AI workforce together.";

quickTaskButtons.forEach((button) => {
  button.addEventListener("click", () => {
    if (!chatInput) return;
    chatInput.value = button.dataset.task || "";
    chatInput.focus();
  });
});

async function updateWorkforceStatus() {
  if (!botAgents.length) return;
  try {
    const response = await fetch("/api/workforce");
    if (!response.ok) return;
    const agents = await response.json();
    botAgents.forEach((bot) => {
      const agent = agents.find((item) => item.name.toLowerCase() === bot.dataset.agentName);
      if (!agent) return;
      bot.classList.toggle("is-active", agent.status === "working");
      const status = bot.querySelector("i");
      if (status) status.textContent = agent.status;
    });
  } catch {
    // The visual fallback continues if the local status endpoint is unavailable.
  }
}

botAgents.forEach((bot) => {
  const name = bot.querySelector("strong");
  if (name) bot.dataset.agentName = name.textContent.toLowerCase();
});

updateWorkforceStatus();
window.setInterval(updateWorkforceStatus, 2000);

const activityMessages = [
  "Alexis is mapping market signals",
  "Gabriel queued an execution plan",
  "Isaac prepared a growth experiment",
  "Marlene summarized a support pattern",
];
let activityIndex = 0;
let liveTaskActive = false;

function setLiveActivity(message) {
  if (!activityEntries.length) return;
  activityEntries[0].textContent = message;
  activityEntries[0].parentElement.querySelector(".activity-time").textContent = "NOW";
}

if (activityEntries.length) {
  window.setInterval(() => {
    if (liveTaskActive) return;
    activityIndex = (activityIndex + 1) % activityMessages.length;
    const words = activityMessages[activityIndex].split(" ");
    activityEntries[0].innerHTML = `<strong>${words[0]}</strong> ${words.slice(1).join(" ")}`;
    activityEntries[0].parentElement.querySelector(".activity-time").textContent = "NOW";
  }, 3200);
}

function speakWithBrowser() {
  if (!("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const greeting = new SpeechSynthesisUtterance(welcomeText);
  const voices = window.speechSynthesis.getVoices();
  const preferredVoice = voices.find((voice) =>
    /en[-_](US|GB|AU|CA)/i.test(voice.lang) &&
    /(natural|neural|samantha|ava|google us english|microsoft.*online)/i.test(voice.name)
  ) || voices.find((voice) => /en[-_]/i.test(voice.lang));
  if (preferredVoice) greeting.voice = preferredVoice;
  greeting.lang = "en-US";
  greeting.rate = 0.88;
  greeting.pitch = 1.02;
  window.speechSynthesis.speak(greeting);
  return true;
}

async function speakWelcome() {
  if (speakWithBrowser()) {
    if (welcomeAudio) welcomeAudio.textContent = "Speaking...";
    window.setTimeout(() => {
      if (welcomeAudio) welcomeAudio.textContent = "Hear welcome";
    }, 2200);
    return;
  }

  if (welcomeAudio) welcomeAudio.textContent = "Loading voice...";
  try {
    const response = await fetch("/api/speech", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: welcomeText }),
    });
    if (!response.ok) throw new Error("Generated voice is not configured.");
    const audio = new Audio(URL.createObjectURL(await response.blob()));
    await audio.play();
  } catch {
    speakWithBrowser();
  } finally {
    if (welcomeAudio) welcomeAudio.textContent = "Hear welcome";
  }
}

function setChatOpen(isOpen) {
  if (!chatLauncher || !chatPanel) return;
  chatPanel.hidden = !isOpen;
  chatLauncher.setAttribute("aria-expanded", String(isOpen));
  if (isOpen) speakWelcome();
  if (isOpen) loadTaskHistory();
  if (isOpen && chatInput) chatInput.focus();
}

async function loadTaskHistory() {
  if (!taskHistoryList) return;
  try {
    const response = await fetch("/api/tasks");
    if (!response.ok) return;
    const tasks = await response.json();
    taskHistoryList.replaceChildren();
    tasks.slice(0, 3).forEach((task) => {
      const item = document.createElement("button");
      item.className = "task-history-item";
      const message = document.createElement("span");
      const status = document.createElement("span");
      message.textContent = `${task.agent}: ${task.message}`;
      status.textContent = task.status;
      item.append(message, status);
      item.addEventListener("click", () => showTaskResult(task));
      taskHistoryList.appendChild(item);
    });
  } catch {
    taskHistoryList.replaceChildren();
  }
}

function showTaskResult(task) {
  if (!taskResult) return;
  taskResult.hidden = false;
  taskResult.querySelector(".task-result-meta").textContent = `${task.agent} / ${task.role} / ${task.status}`;
  taskResult.querySelector("p").textContent = task.result || task.error || "This task is still in progress.";
}

function setChatMinimized(isMinimized) {
  if (!chatPanel || !chatMinimize) return;
  chatPanel.classList.toggle("is-collapsed", isMinimized);
  chatMinimize.setAttribute("aria-expanded", String(!isMinimized));
  chatMinimize.setAttribute("aria-label", isMinimized ? "Expand chat" : "Minimize chat");
  chatMinimize.textContent = isMinimized ? "+" : "-";
}

function addChatMessage(text, role) {
  const message = document.createElement("div");
  message.className = `chat-message ${role}`;
  message.textContent = text;
  chatMessages.appendChild(message);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return message;
}

if (chatLauncher && chatClose && chatMinimize && chatForm && chatInput && chatMessages) {
  chatLauncher.addEventListener("click", () => setChatOpen(true));
  chatClose.addEventListener("click", () => setChatOpen(false));
  chatMinimize.addEventListener("click", () => {
    setChatMinimized(!chatPanel.classList.contains("is-collapsed"));
  });

  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;

    addChatMessage(message, "user");
    chatInput.value = "";
    chatInput.disabled = true;
    liveTaskActive = true;
    setLiveActivity("Routing request to the workforce");
    const pending = addChatMessage("Thinking...", "assistant pending");

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "The system is unavailable.");
      pending.textContent = data.agent ? `${data.agent} / ${data.role}: ${data.reply}` : data.reply;
      setLiveActivity(data.agent ? `${data.agent} is handling your request` : "Workforce response received");
      loadTaskHistory();
      pending.classList.remove("pending");
    } catch (error) {
      pending.textContent = `${error.message} Start the local server, then try again.`;
      setLiveActivity("Workforce waiting for configuration");
      loadTaskHistory();
      pending.classList.remove("pending");
    } finally {
      chatInput.disabled = false;
      chatInput.focus();
      window.setTimeout(() => {
        liveTaskActive = false;
      }, 7000);
    }
  });
}

if (welcomeAudio) {
  welcomeAudio.addEventListener("click", speakWelcome);
}

const logoBots = document.querySelectorAll(".logo-mark");

function playEvilTone(frequency, duration, type = "sawtooth", volume = 0.02) {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return;

  const ctx = new AudioCtx();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.value = frequency;

  gain.gain.value = volume;
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start();
  osc.stop(ctx.currentTime + duration);
}

function triggerBotAudio() {
  playEvilTone(220, 0.14, "triangle", 0.018);
  setTimeout(() => playEvilTone(170, 0.18, "sawtooth", 0.016), 80);
  setTimeout(() => playEvilTone(130, 0.2, "square", 0.012), 180);
}

logoBots.forEach((bot) => {
  bot.addEventListener("mouseenter", () => {
    triggerBotAudio();
  });

  bot.addEventListener("click", () => {
    triggerBotAudio();
    bot.classList.add("bot-laugh");
    setTimeout(() => bot.classList.remove("bot-laugh"), 450);
  });

  bot.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      triggerBotAudio();
      bot.classList.add("bot-laugh");
      setTimeout(() => bot.classList.remove("bot-laugh"), 450);
    }
  });
});
