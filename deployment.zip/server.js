const http = require("http");
const fs = require("fs");
const path = require("path");

loadEnvFile();

const port = Number(process.env.PORT) || 3000;
const root = __dirname;
const host = process.env.HOST || "0.0.0.0";
const tasksPath = process.env.TASKS_FILE
  ? path.resolve(root, process.env.TASKS_FILE)
  : path.join(root, "tasks.json");
const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
};

const agents = [
  {
    name: "Alexis",
    role: "Research",
    description: "gathers information, compares sources, and produces concise decision briefs",
    keywords: ["research", "competitor", "competitors", "analyze", "analysis", "market", "sources", "report"],
  },
  {
    name: "Gabriel",
    role: "Operations",
    description: "turns approved plans into tasks, checklists, and repeatable workflows",
    keywords: ["task", "tasks", "workflow", "automate", "automation", "process", "operations", "execute"],
  },
  {
    name: "Isaac",
    role: "Growth",
    description: "develops messaging, content experiments, and practical customer-growth actions",
    keywords: ["growth", "marketing", "content", "sales", "customer", "campaign", "outreach", "conversion"],
  },
  {
    name: "Marlene",
    role: "Support",
    description: "answers customer questions, triages issues, and summarizes recurring needs",
    keywords: ["support", "help", "issue", "problem", "customer", "question", "ticket", "complaint"],
  },
];

const agentRoles = agents
  .map((agent) => `${agent.name} (${agent.role}): ${agent.description}.`)
  .join(" ");

let tasks = loadTasks();

function loadTasks() {
  if (!fs.existsSync(tasksPath)) return [];
  try {
    return JSON.parse(fs.readFileSync(tasksPath, "utf8"));
  } catch {
    return [];
  }
}

function saveTasks() {
  fs.writeFileSync(tasksPath, JSON.stringify(tasks.slice(0, 50), null, 2));
}

function createTask(agent, message) {
  const task = {
    id: `task-${Date.now()}`,
    agent: agent.name,
    role: agent.role,
    message,
    status: "working",
    createdAt: new Date().toISOString(),
  };
  tasks.unshift(task);
  saveTasks();
  return task;
}

function updateTask(taskId, updates) {
  const task = tasks.find((item) => item.id === taskId);
  if (!task) return;
  Object.assign(task, updates, { updatedAt: new Date().toISOString() });
  saveTasks();
}

function chooseAgent(message) {
  const normalizedMessage = message.toLowerCase();
  const rankedAgents = agents.map((agent) => ({
    agent,
    score: agent.keywords.reduce((score, keyword) => score + (normalizedMessage.includes(keyword) ? 1 : 0), 0),
  }));
  rankedAgents.sort((first, second) => second.score - first.score);
  return rankedAgents[0].score > 0 ? rankedAgents[0].agent : agents[0];
}

const agentState = new Map(agents.map((agent) => [agent.name, { status: "ready", task: "" }]));

function setAgentState(agent, status, task = "") {
  agentState.set(agent.name, { status, task });
}

function handleWorkforce(request, response) {
  sendJson(response, 200, agents.map((agent) => ({
    name: agent.name,
    role: agent.role,
    status: agentState.get(agent.name).status,
    task: agentState.get(agent.name).task,
  })));
}

function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;

  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) {
      process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, "");
    }
  }
}

function sendJson(response, status, payload) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(payload));
}

function readBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 10_000) reject(new Error("Request too large."));
    });
    request.on("end", () => resolve(body));
    request.on("error", reject);
  });
}

async function handleChat(request, response) {
  if (!process.env.OPENAI_API_KEY) {
    sendJson(response, 503, { error: "Add OPENAI_API_KEY to .env before starting the AI concierge." });
    return;
  }

  let assignedAgent = null;
  let task = null;
  try {
    const body = JSON.parse(await readBody(request));
    const message = typeof body.message === "string" ? body.message.trim() : "";
    if (!message || message.length > 1_000) {
      sendJson(response, 400, { error: "Send a message between 1 and 1,000 characters." });
      return;
    }

    assignedAgent = chooseAgent(message);
    setAgentState(assignedAgent, "working", message.slice(0, 80));
    task = createTask(assignedAgent, message);

    const aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0.4,
        messages: [
          {
            role: "system",
            content: `You are the concise AI workforce concierge for NoBullshitAIworld. The workforce has four specialized agents: ${agentRoles} The visitor's request has been assigned to ${assignedAgent.name}, the ${assignedAgent.role} agent. Answer from that agent's perspective, explain how the team can work together while humans keep strategic control, and recommend a practical next action. Explain Starter ($29), Pro ($79), or Enterprise (custom) when relevant. Be direct, useful, and never invent guarantees. Keep replies under 100 words.`,
          },
          { role: "user", content: message },
        ],
      }),
    });

    const result = await aiResponse.json();
    if (!aiResponse.ok) {
      setAgentState(assignedAgent, "ready");
      updateTask(task.id, { status: "failed", error: result.error?.message || "The AI provider returned an error." });
      sendJson(response, 502, { error: result.error?.message || "The AI provider returned an error." });
      return;
    }

    setAgentState(assignedAgent, "ready");
    updateTask(task.id, { status: "completed", result: result.choices?.[0]?.message?.content || "" });
    sendJson(response, 200, {
      reply: result.choices?.[0]?.message?.content || "I could not generate a response.",
      agent: assignedAgent.name,
      role: assignedAgent.role,
      taskId: task.id,
    });
  } catch (error) {
    if (assignedAgent) setAgentState(assignedAgent, "ready");
    if (task) updateTask(task.id, { status: "failed", error: error.message || "Invalid request." });
    sendJson(response, 400, { error: error.message || "Invalid request." });
  }
}

function handleTasks(request, response) {
  sendJson(response, 200, tasks);
}

async function handleSpeech(request, response) {
  if (!process.env.OPENAI_API_KEY) {
    sendJson(response, 503, { error: "Add OPENAI_API_KEY to .env before using generated voice." });
    return;
  }

  try {
    const body = JSON.parse(await readBody(request));
    const text = typeof body.text === "string" ? body.text.trim() : "";
    if (!text || text.length > 500) {
      sendJson(response, 400, { error: "Speech text is required and must be under 500 characters." });
      return;
    }

    const audioResponse = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: process.env.OPENAI_TTS_MODEL || "tts-1",
        voice: process.env.OPENAI_TTS_VOICE || "nova",
        input: text,
        response_format: "mp3",
      }),
    });

    if (!audioResponse.ok) {
      const result = await audioResponse.json();
      sendJson(response, 502, { error: result.error?.message || "The voice provider returned an error." });
      return;
    }

    response.writeHead(200, { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" });
    response.end(Buffer.from(await audioResponse.arrayBuffer()));
  } catch (error) {
    sendJson(response, 400, { error: error.message || "Invalid speech request." });
  }
}

function serveStatic(request, response) {
  const requestedPath = request.url === "/" ? "/index.html" : request.url.split("?")[0];
  const filePath = path.resolve(root, `.${requestedPath}`);
  if (!filePath.startsWith(root) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    response.writeHead(404);
    response.end("Not found");
    return;
  }

  response.writeHead(200, { "Content-Type": contentTypes[path.extname(filePath)] || "text/plain; charset=utf-8" });
  fs.createReadStream(filePath).pipe(response);
}

const server = http.createServer((request, response) => {
  if (request.method === "GET" && request.url === "/health") {
    sendJson(response, 200, { status: "ok", service: "nobullshit-aiworld" });
    return;
  }
  if (request.method === "GET" && request.url === "/api/workforce") {
    handleWorkforce(request, response);
    return;
  }
  if (request.method === "GET" && request.url === "/api/tasks") {
    handleTasks(request, response);
    return;
  }
  if (request.method === "POST" && request.url === "/api/chat") {
    handleChat(request, response);
    return;
  }
  if (request.method === "POST" && request.url === "/api/speech") {
    handleSpeech(request, response);
    return;
  }
  if (request.method === "GET") {
    serveStatic(request, response);
    return;
  }
  sendJson(response, 405, { error: "Method not allowed." });
});

server.listen(port, host, () => {
  console.log(`NoBullshitAIworld running on ${host}:${port}`);
});
