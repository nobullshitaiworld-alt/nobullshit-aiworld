# NoBullshitAIworld

## Run locally

1. Copy `.env.example` to `.env`.
2. Add `OPENAI_API_KEY` to `.env` for live chat responses.
3. Start the server:

```powershell
npm.cmd start
```

Open `http://localhost:3000`.

## Deploy

Use any Node.js host that supports a long-running server. Set the environment variables from `.env.example` in the host dashboard, especially `OPENAI_API_KEY`.

The app listens on `0.0.0.0` and uses the host-provided `PORT`. Configure `TASKS_FILE` to point at persistent storage. If the host has an ephemeral filesystem, replace the JSON task store with a hosted database before relying on task history.

The health check is available at `/health`.